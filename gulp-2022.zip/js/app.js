import * as flsFunctions from "./modules/functions.js"

flsFunctions.isWebp();

import Swiper, { Navigation, Pagination } from 'swiper';  // core version + navigation, pagination modules:

const swiper = new Swiper();  // init Swiper: